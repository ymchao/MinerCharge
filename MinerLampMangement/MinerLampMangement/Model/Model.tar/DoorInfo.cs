﻿using System;
using MinerLampMangement.Enum;
using MongoDB.Bson.Serialization.Attributes;

namespace MinerLampMangement.Model
{
    /// <summary>
    /// 柜门信息
    /// </summary>
    public class DoorInfo
    {
        /// <summary>
        /// 矿工MinerObjectId
        /// </summary>
        public string MinerObjectId { get; set; }

        /// <summary>
        /// 矿灯状态开始时间
        /// </summary>
        public string StatusTime { get; set; }

        /// <summary>
        ///  矿灯状态
        /// </summary>
        public MinerLampStatus MinerLampStatus { get; set; }
    }
}