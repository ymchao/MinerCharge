﻿using System;
using System.Collections.Generic;

namespace MinerLampMangement.Model
{
    /// <summary>
    /// 充电柜实体类
    /// </summary>
    public class CabinetInfo : BaseEntity
    {
        /// <summary>
        /// 充电柜名称
        /// </summary>
        public int Name { get; set; }

        /// <summary>
        /// 获取 正在充电矿灯个数
        /// </summary>
        public int Charging { get; set; }

        /// <summary>
        /// 获取 充满个数
        /// </summary>
        public int Full { get; set; }

        /// <summary>
        /// 获取 正在使用个数
        /// </summary>
        public int Using { get; set; }

        /// <summary>
        /// 获取 故障个数
        /// </summary>
        public int Problem { get; set; }

        /// <summary>
        /// 柜门组
        /// </summary>
        public List<DoorInfo> DoorInfo { set; get; }

        /// <summary>
        /// 重写tostring 将文档输出为jason格式
        /// </summary>
        /// <returns></returns>
//        public override string ToString()
//        {
//            return  JsonConvert.SerializeObject(this);
//        }
    }
}