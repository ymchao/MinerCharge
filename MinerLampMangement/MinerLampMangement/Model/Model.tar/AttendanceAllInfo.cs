﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace MinerLampMangement.Model
{
    public class AttendanceAllInfo : BaseEntity
    {
        public List<AttendanceInfo> AttendanceInfos { get; set; }
    }
}