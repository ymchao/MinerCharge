﻿using Newtonsoft.Json;
using System;
using MinerLampMangement.Enum;

namespace MinerLampMangement.Model
{
    public class AttendanceInfo
    {
        /// <summary>
        ///  矿灯状态
        /// </summary>
        public MinerLampStatus MinerLampStatus { get; set; }

        /// <summary>
        ///  矿灯状态时间
        /// </summary>
        public DateTime MinerLampStatusTime { get; set; }

    }
}